<?php

namespace CommerceLoyalty\CustomerLoyaltyLevelSystem\Block\Adminhtml\Form\Field;

use Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray;
use Magento\Framework\View\Element\Html\Select;

class TagRows extends AbstractFieldArray
{
    protected function _prepareToRender()
    {
        // Status First (Professional Toggle)
        $this->addColumn('status', [
            'label' => __('Status'),
            'renderer' => $this->getStatusRenderer(),
            'style' => 'width:110px'
        ]);

        // Tier Name (Primary Identity Field)
        $this->addColumn('tier_name', [
            'label' => __('Membership Tier Name'),
            'style' => 'width:240px',
            'class' => 'required-entry'
        ]);

        // Minimum Spend
        $this->addColumn('minimum_spend', [
            'label' => __('Minimum Spend Threshold'),
            'style' => 'width:160px',
            'class' => 'validate-number'
        ]);

        // Discount
        $this->addColumn('reward_discount', [
            'label' => __('Reward Discount (%)'),
            'style' => 'width:150px',
            'class' => 'validate-number'
        ]);

        // Validity
        $this->addColumn('validity_period', [
            'label' => __('Validity Period (Days)'),
            'style' => 'width:150px',
            'class' => 'validate-number'
        ]);

        // Usage Cap
        $this->addColumn('tier_cap', [
            'label' => __('Tier Usage Cap'),
            'style' => 'width:140px',
            'class' => 'validate-number'
        ]);

        $this->_addAfter = false;
        $this->_addButtonLabel = __('Add Membership Tier');
    }

    private function getStatusRenderer()
    {
        $renderer = $this->getLayout()->createBlock(
            Select::class,
            '',
            ['data' => ['is_render_to_js_template' => true]]
        );

        $renderer->setOptions([
            ['value' => '1', 'label' => __('Active')],
            ['value' => '0', 'label' => __('Inactive')],
        ]);

        return $renderer;
    }
}